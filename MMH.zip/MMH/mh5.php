<html>
<body bgcolor="98fb98" style="font-family:CURSIVE;">
<center> <h1 style="color:brown;font-size:50px;">Taj Krishna Hyderabad </h1></center>
<center>
<form action="" method="post">
<h1>Booking Details</h1>
Firstname:<input type ="text" name="fname" placeholder="enter Firstname" required><br>
Lastname:<input type ="text" name="lname" placeholder="enter Lastname" required><br><br>
<p style="text-align:left;">No of Rooms:<select name="no" id="no">
<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option></select><br></p>
Email:<input type="email" name="email"placeholder="enter your email" required><br>
Phone No:<input type="number" name="phno" placeholder="Phone Number" required><br>

<input type="submit"  onClick="book()" value="Confirm & Pay" name="book" style="font-size:30;
background-color:#ff4500;
display:inline-block;
font-family:CURSIVE;
margin-right:25px;
margin-top:30px;
color:white;" required/>
</form>

<style>
input{
font-size:20;

display:inline-block;
font-family:CURSIVE;
margin-right:25px;
margin-top:30px;
}
form{
border:solid;
margin-left:450;
margin-top:100;
background-color:#ffc0cb;
margin-right:450;
font-size:20;
font-family:CURSIVE;
}
</style></center>
<script type="text/javascript">
function book()
{
var n1=document.getElementById("no").value;
alert("Your Booking is Confirmed and you need to pay :Rs."+n1*8550);
}                                                                                                                                                                                                                                                                                                           
</script>
<?php

$con = mysqli_connect("localhost","root","","mmhr");
if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
	
if(isset($_POST['book'])){
		$fname=$_POST['fname'];
	    $lname=$_POST['lname'];
         $no=$_POST['no'];
		$email=$_POST['email'];
		
		
		$phno=$_POST['phno'];
		

		$insert="INSERT INTO nn5(fname,lname,no,emaill,phno) VALUES ('$fname','$lname','$no','$email','$phno')";
         $var =mysqli_query($con, $insert);
		 if($var===true){
			 
			 		 	$var=$no*8550;
			 		 	echo "<script>alert('Process your Payment Rs.'+$var)</script>";
						echo "<script>window.open('pay.html','_self')</script>";

			 }
			 else
				 			 		 	echo "<script>alert('data not entered!!')</script>";

				 

	   }
	   ?>
</body>
</html>

