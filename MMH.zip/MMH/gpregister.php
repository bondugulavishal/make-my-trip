<html>
<body background="i4.jpg">
<center>
<form action="" method="POST">
<h1>Register</h1>
Firstname:<input type ="text" name="fname" placeholder="enter Firstname" required><br>
Lastname:<input type ="text" name="lname" placeholder="enter Lastname" required><br>
Date Of Birth:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="date" name="dob" required><br>
Email:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="email" name="email"placeholder="enter your email" required><br>
Phone No:&nbsp;<input type="number" name="phno" placeholder="Phone Number" required><br>
Password:&nbsp;<input type="password" name="pwd" placeholder="password" required ><br>
<input type="submit" name="register" value="Register" style="font-size:30;
background-color:#ff4500;
display:inline-block;
font-family:CURSIVE;
margin-right:25px;
margin-top:30px;
color:white;" required>
<style>
input{
font-size:20;

display:inline-block;
font-family:CURSIVE;
margin-right:25px;
margin-top:30px;
}
form{
border:solid;
margin-left:450;
margin-top:100;
background-color:#32cd32;
margin-right:450;
font-size:20;
font-family:CURSIVE;
}
</style></center>
<?php

$con = mysqli_connect("localhost","root","","mmhr");
if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
	
if(isset($_POST['register'])){
		$fname=$_POST['fname'];
	    $lname=$_POST['lname'];
         $dob=$_POST['dob'];
		$email=$_POST['email'];
		
		
		$phno=$_POST['phno'];
		$pwd=$_POST['pwd'];

		$insert="INSERT INTO t1(fname,lname,dob,emaill,phno,passwor) VALUES ('$fname','$lname','$dob','$email','$phno','$pwd')";
         $var =mysqli_query($con, $insert);
		 if($var===true){
			 		 	echo "<script>alert('data entered!!')</script>";
echo "<script>window.open('gp1.html','_self')</script>";
			 }
			 else
				 			 		 	echo "<script>alert('data not entered!!')</script>";

				 

	   }
	   ?>
</body>
</html>
