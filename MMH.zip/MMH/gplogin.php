<html>
<body background="i4.jpg">
<center>
<form action="" method="post">
<h1>Login</h1>
Email:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="email" name="email"placeholder="enter your email" required><br>
Password:&nbsp;&nbsp;<input type="password" name="pwd" placeholder="password" required><br>
<input type="submit" name="login" value="Login  " style="font-size:30;
background-color:#ff4500;
display:inline-block;
font-family:CURSIVE;
margin-right:25px;
margin-top:30px;
color:white;"></a>
<style>

input{
font-size:20;

display:inline-block;
font-family:CURSIVE;
margin-right:25px;
margin-top:30px;
}
form{
border:solid;
margin-left:450;
margin-top:150;
background-color:#32cd32;
margin-right:450;
font-size:20;
font-family:CURSIVE;
}
</style></center>
<?php

$con = mysqli_connect("localhost","root","","mmhr");
if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
	
if(isset($_POST['login'])){
		$email=$_POST['email'];
	    $pwd=$_POST['pwd'];
		$sel_c = "select * from t1 where emaill='$email' AND passwor='$pwd'";
		
	$query= mysqli_query($con,$sel_c);
		
		$num = mysqli_num_rows($query);
		if($num==0)
			echo "<script>alert('login failed!!')</script>";
		else{
			
			echo "<script>alert('login succesfull!!')</script>";
			echo "<script>window.open('gphome.html','_self')</script>";
			
		}
		
		
}
?>
</body>
</html>
