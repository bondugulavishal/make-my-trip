<html>
<head>
<style>
body{
background-image:url("c.jpg");
background-size:100% 100%;
background-repeat:no-repeat;
font-family:cursive;
}
input{
font-size:25;

display:inline-block;
font-family:CURSIVE;
margin-right:25px;
margin-top:30px;
}
form{


font-size:25;
font-family:CURSIVE;
}
</style></head>
<body ><center> <H1 style="font-family:CURSIVE;font-size:40">MAKE MY HOLIDAY</H1>
<H1 style="font-family:CURSIVE;font-size:">Contact</H1>
<form action="" method="post">
<p>Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="name" ><br>
ContactNo :&nbsp;<input type="Number" name="phno"><br>
Email:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="email" name="email"><br>
Complaint/Feedback:<input type="text" style="width:300px;height:100px;" name="fb"><br>
<input type="submit" name="button" value="Submit"></p>
</form>
</center>
<?php

$con = mysqli_connect("localhost","root","","mmhr");
if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
	
if(isset($_POST['button'])){
		$name=$_POST['name'];
	    $phno=$_POST['phno'];
         
		$email=$_POST['email'];
		
		
		$fb=$_POST['fb'];
		

		$insert="INSERT INTO c1(name,phno,emaill,fb) VALUES ('$name','$phno','$email','$fb')";
         $var =mysqli_query($con, $insert);
		 if($var===true){
			 		 	echo "<script>alert('Complaint/Feedback is Registered!!')</script>";
echo "<script>window.open('gphome.html','_self')</script>";
			 }
			 else
				 			 		 	echo "<script>alert('Complaint/Feedback is not entered!!')</script>";

				 

	   }
	   ?>
</body>
</html>
