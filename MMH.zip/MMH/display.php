<html><body>
<form action="" method="post">
<input type="submit" name="display" value="display"/>
</form>
<?php

$conn = mysqli_connect("localhost","root","","mmhr");
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
	
if(isset($_POST['display'])){
$sql = "SELECT ht1.fname, ht1.lname, ht1.phno FROM ht1";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($result)) {
        echo "fname: " . $row["fname"]. " - LName: " . $row["lname"]. " " . $row["phno"]. "<br>";
    }
} else {
    echo "0 results";
}}
mysqli_close($conn);
?>
