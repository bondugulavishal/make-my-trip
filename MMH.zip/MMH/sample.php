<html><body>
<form action="" method="post">
<input type="submit" name="display" value="display"/>
</form>
<?php

$con=mysqli_connect('localhost','root','','sample');
$q="SELECT sequence,fname,lname,emaill,userr,passwor from regu1";
$q1=$con->query($q);

?>
<table align="center" border="1px" style="width:600px ; line-height: 40px;"  cellpadding="4" cellspacing="5">
	<tr>
	<th>sequence</th>
	
<th>	FName</th>
<th>	lname</th>
<th>no</th>
<th>emaill</th>

	
</tr>



<?php 

	while($row=$q1->fetch_assoc())
	{
		?>
		<tr>
		<
			<td><?php echo $row['fname']; ?></td>
			
			<td><?php echo $row['lname']; ?></td>
			
			<td><?php echo $row['emaill']; ?></td>
			<td><?php echo $row['userr']; ?></td>
			<td><?php echo $row['passwor']; ?></td>
			
			</tr>
			<?php 
}

?>
	
</table>