<center style="font-family:cursive;"><h1>Booking Details of The Westin Hyderabad Mindspace</h1></center>
<?php

$con=mysqli_connect('localhost','root','','mmhr');
$q="SELECT fname,lname,no,emaill,phno from nn4";
$q1=$con->query($q);

?>
<table align="center" border="1px" style="width:600px ; line-height: 40px;"  cellpadding="4" cellspacing="5">
	<tr>
<th>	FirstName</th>
<th>LastName</th>
<th>No of Rooms</th>
<th>	Email</th>

	<th>ContactNo</th>
</tr>



<?php 

	 while($row = mysqli_fetch_assoc($q1)) 
	{
		?>
		<tr>
			<td><?php echo $row['fname']; ?></td>
			<td><?php echo $row['lname']; ?></td>
			<td><?php echo $row['no']; ?></td>
			<td><?php echo $row['emaill']; ?></td>
			<td><?php echo $row['phno']; ?></td>
			
			
			</tr>
			<?php 
}

?>
	
</table>