<html>
<body>
<html><body>
<form action="nn.php" method="post">
<input type="submit" name="display" value="display"/>
</form>